package com.example.zahid.a3dtryon;

/**
 * Created by Zahid on 23-Jul-18.
 */
public interface PlaybackHandler {
    public void onPreparePlayback();
}