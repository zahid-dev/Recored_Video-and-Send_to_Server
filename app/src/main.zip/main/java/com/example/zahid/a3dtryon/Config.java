package com.example.zahid.a3dtryon;

/**
 * Created by Zahid on 23-Jul-18.
 */


public class Config {
    // File upload url (replace the ip with your server address)
    public static final String FILE_UPLOAD_URL = "http://192.168.0.103/AndroidFileUpload/fileUpload.php";
    public static final String action = "http://192.168.0.103/AndroidFileUpload/action.php";
    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
}